@file:OptIn(ExperimentalMaterial3Api::class)

package com.refreshx.app.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.refreshx.app.MainViewModel
import com.refreshx.app.Perms

@Composable
fun MainScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme

    val enabled by vm.enabled.collectAsStateWithLifecycle()
    val hz by vm.targetHz.collectAsStateWithLifecycle()
    val on by vm.serviceOn.collectAsStateWithLifecycle()
    val apps by vm.apps.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()

    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    val perms = remember(tick) { Perms.state(ctx) }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    var query by rememberSaveable { mutableStateOf("") }
    var onlySelected by rememberSaveable { mutableStateOf(false) }

    val filtered = remember(apps, query, onlySelected, enabled) {
        apps.filter {
            (!onlySelected || it.pkg in enabled) &&
                (query.isBlank() || it.label.contains(query, ignoreCase = true) || it.pkg.contains(query, ignoreCase = true))
        }
    }

    Box(Modifier.fillMaxSize().background(cs.background)) {
        // Soft premium gradient glow at the top
        Box(
            Modifier.fillMaxWidth().height(420.dp).background(
                Brush.verticalGradient(listOf(cs.primaryContainer.copy(alpha = 0.55f), cs.background))
            )
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 16.dp,
                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 32.dp,
            ),
        ) {
            item(key = "header") { Entrance(0) { Header() } }

            item(key = "hero") {
                Entrance(1) {
                    HeroCard(
                        on = on,
                        hz = hz,
                        ready = perms.core,
                        enabledCount = enabled.size,
                        onToggle = {
                            if (on) {
                                vm.setService(false)
                            } else if (perms.core) {
                                if (Build.VERSION.SDK_INT >= 33 && !perms.notif) {
                                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                                vm.setService(true)
                            }
                        },
                        modifier = Modifier.padding(bottom = 14.dp),
                    )
                }
            }

            item(key = "setup") {
                Entrance(2) {
                    AnimatedVisibility(
                        visible = !(perms.core && perms.notif),
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically(spring(stiffness = Spring.StiffnessMediumLow)),
                    ) {
                        SetupCard(
                            write = perms.write,
                            usage = perms.usage,
                            notif = perms.notif,
                            onWrite = { Perms.openWrite(ctx) },
                            onUsage = { Perms.openUsage(ctx) },
                            onNotif = {
                                if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                else Perms.openAppSettings(ctx)
                            },
                            modifier = Modifier.padding(bottom = 14.dp),
                        )
                    }
                }
            }

            item(key = "hz") {
                Entrance(3) {
                    HzCard(
                        rates = vm.rates,
                        selected = hz,
                        onSelect = vm::setHz,
                        modifier = Modifier.padding(bottom = 14.dp),
                    )
                }
            }

            item(key = "tips") {
                Entrance(4) {
                    TipsCard(
                        onAppSettings = { Perms.openAppSettings(ctx) },
                        onReset = { vm.resetRefresh() },
                        modifier = Modifier.padding(bottom = 22.dp),
                    )
                }
            }

            item(key = "apps_head") {
                Entrance(5) {
                    androidx.compose.foundation.layout.Column(Modifier.padding(bottom = 10.dp)) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                "Apps",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.weight(1f),
                            )
                            AnimatedContent(
                                targetState = enabled.size,
                                transitionSpec = {
                                    (slideInVertically { it } + fadeIn()) togetherWith
                                        (slideOutVertically { -it } + fadeOut())
                                },
                                label = "count",
                            ) { n ->
                                Text(
                                    "$n selected",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = cs.primary,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = query,
                            onValueChange = { query = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Search apps") },
                            leadingIcon = { Icon(Icons.Rounded.Search, null) },
                            trailingIcon = if (query.isNotEmpty()) {
                                { IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Close, null) } }
                            } else null,
                            singleLine = true,
                            shape = CircleShape,
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = !onlySelected,
                                onClick = { onlySelected = false },
                                label = { Text("All") },
                                shape = CircleShape,
                            )
                            FilterChip(
                                selected = onlySelected,
                                onClick = { onlySelected = true },
                                label = { Text("Selected") },
                                shape = CircleShape,
                            )
                        }
                    }
                }
            }

            if (loading) {
                item(key = "loading") {
                    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            }

            items(filtered, key = { it.pkg }) { app ->
                AppRow(
                    app = app,
                    checked = app.pkg in enabled,
                    onChange = { vm.toggleApp(app.pkg, it) },
                    modifier = Modifier.animateItem(
                        fadeInSpec = tween(300),
                        placementSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow),
                        fadeOutSpec = tween(200),
                    ),
                )
            }

            if (!loading && filtered.isEmpty()) {
                item(key = "empty") {
                    Text(
                        "Koi app malyo nahi",
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                        textAlign = TextAlign.Center,
                        color = cs.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyLarge,
                    )
                }
            }
        }
    }
}
