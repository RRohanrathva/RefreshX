package com.refreshx.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.refreshx.app.MainViewModel
import com.refreshx.app.Perms
import com.refreshx.app.ShizukuHelper

@Composable
fun MainScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme

    val appRates by vm.appRates.collectAsStateWithLifecycle()
    val shizuku by vm.shizuku.collectAsStateWithLifecycle()
    val setupTick by vm.setupTick.collectAsStateWithLifecycle()
    val apps by vm.apps.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val diag by vm.diag.collectAsStateWithLifecycle()

    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        tick++
        ShizukuHelper.refresh(ctx)
        vm.sync()
    }
    LaunchedEffect(setupTick) {
        tick++
        vm.sync()
    }
    val ready = remember(tick, setupTick) { Perms.state(ctx).core }

    var query by rememberSaveable { mutableStateOf("") }
    var onlyActive by rememberSaveable { mutableStateOf(false) }

    val filtered = remember(apps, query, onlyActive, appRates) {
        apps.filter {
            (!onlyActive || (appRates[it.pkg] ?: 0) > 0) &&
                (query.isBlank() || it.label.contains(query, ignoreCase = true) || it.pkg.contains(query, ignoreCase = true))
        }
    }

    Box(Modifier.fillMaxSize().background(cs.background)) {
        Box(
            Modifier.fillMaxWidth().height(420.dp).background(
                Brush.verticalGradient(listOf(cs.primaryContainer.copy(alpha = 0.55f), cs.background))
            )
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 16.dp,
                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 32.dp,
            ),
        ) {
            item(key = "header") { Entrance(0) { Header() } }

            item(key = "status") {
                Entrance(1) {
                    AnimatedContent(
                        targetState = ready,
                        transitionSpec = { fadeIn(tween(350)) togetherWith fadeOut(tween(250)) },
                        modifier = Modifier.padding(bottom = 18.dp),
                        label = "status",
                    ) { ok ->
                        if (ok) {
                            ReadyPill()
                        } else {
                            ShizukuCard(
                                state = shizuku,
                                onOpen = { Perms.openShizuku(ctx) },
                                onAllow = { vm.requestShizuku() },
                                onRetry = { vm.retrySetup() },
                            )
                        }
                    }
                }
            }

            item(key = "diag") {
                Entrance(2) {
                    DiagCard(
                        text = diag,
                        testHz = vm.rates.max(),
                        onRefresh = { vm.refreshDiag() },
                        onTest = { vm.testRate(vm.rates.max()) },
                        onReset = { vm.resetTest() },
                        modifier = Modifier.padding(bottom = 18.dp),
                    )
                }
            }

            item(key = "search") {
                Entrance(2) {
                    Column(Modifier.padding(bottom = 10.dp)) {
                        OutlinedTextField(
                            value = query,
                            onValueChange = { query = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Search apps") },
                            leadingIcon = { Icon(Icons.Rounded.Search, null) },
                            trailingIcon = if (query.isNotEmpty()) {
                                { IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Close, null) } }
                            } else null,
                            singleLine = true,
                            shape = CircleShape,
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = !onlyActive,
                                onClick = { onlyActive = false },
                                label = { Text("All apps") },
                                shape = CircleShape,
                            )
                            FilterChip(
                                selected = onlyActive,
                                onClick = { onlyActive = true },
                                label = { Text("Active (${appRates.size})") },
                                shape = CircleShape,
                            )
                        }
                    }
                }
            }

            if (loading) {
                item(key = "loading") {
                    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            }

            items(filtered, key = { it.pkg }) { app ->
                AppRow(
                    app = app,
                    rate = appRates[app.pkg] ?: 0,
                    rates = vm.rates,
                    onRate = { vm.setRate(app.pkg, it) },
                    modifier = Modifier.animateItem(
                        fadeInSpec = tween(300),
                        placementSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow),
                        fadeOutSpec = tween(200),
                    ),
                )
            }

            if (!loading && filtered.isEmpty()) {
                item(key = "empty") {
                    Text(
                        "Koi app malyo nahi",
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                        textAlign = TextAlign.Center,
                        color = cs.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyLarge,
                    )
                }
            }
        }
    }
}
