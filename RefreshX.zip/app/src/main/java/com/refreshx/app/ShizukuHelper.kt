package com.refreshx.app

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.flow.MutableStateFlow
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread

enum class ShizukuState { NOT_RUNNING, NEEDS_PERMISSION, READY }

/**
 * Shizuku ke through RefreshX ne ek vaar badhi permissions automatic aape chhe
 * (write settings, usage access, secure settings, battery unrestricted).
 */
object ShizukuHelper {
    private const val REQ = 4242

    val state = MutableStateFlow(ShizukuState.NOT_RUNNING)
    val setupTick = MutableStateFlow(0)

    private var initialized = false

    @Volatile
    private var setupRunning = false

    fun init(ctx: Context) {
        if (initialized) return
        initialized = true
        val app = ctx.applicationContext
        Shizuku.addBinderReceivedListenerSticky { refresh(app) }
        Shizuku.addBinderDeadListener { state.value = ShizukuState.NOT_RUNNING }
        Shizuku.addRequestPermissionResultListener { _, _ -> refresh(app) }
    }

    fun refresh(ctx: Context) {
        val s = try {
            when {
                !Shizuku.pingBinder() -> ShizukuState.NOT_RUNNING
                Shizuku.isPreV11() -> ShizukuState.NOT_RUNNING
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> ShizukuState.READY
                else -> ShizukuState.NEEDS_PERMISSION
            }
        } catch (t: Throwable) {
            ShizukuState.NOT_RUNNING
        }
        state.value = s
        if (s == ShizukuState.READY && !Perms.state(ctx).core) setup(ctx)
    }

    fun requestPermission() {
        try {
            Shizuku.requestPermission(REQ)
        } catch (t: Throwable) {
            // ignore
        }
    }

    fun setup(ctx: Context) {
        if (setupRunning) return
        setupRunning = true
        val pkg = ctx.packageName
        thread(name = "shizuku-setup") {
            try {
                exec(
                    listOf(
                        "pm grant $pkg android.permission.WRITE_SECURE_SETTINGS",
                        "appops set $pkg WRITE_SETTINGS allow",
                        "appops set $pkg GET_USAGE_STATS allow",
                        "pm grant $pkg android.permission.POST_NOTIFICATIONS",
                        "appops set $pkg RUN_ANY_IN_BACKGROUND allow",
                        "dumpsys deviceidle whitelist +$pkg",
                    ).joinToString("; ")
                )
            } finally {
                setupRunning = false
                setupTick.value = setupTick.value + 1
            }
        }
    }

    /** Runs a shell command with shell (adb) privileges through Shizuku. */
    fun exec(cmd: String): String? = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java,
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (t: Throwable) {
        null
    }
}
