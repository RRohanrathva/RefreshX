package com.refreshx.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.hardware.display.DisplayManager
import android.provider.Settings
import android.view.Display
import androidx.core.app.NotificationCompat
import kotlin.math.roundToInt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class RefreshService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private lateinit var store: Store

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        store = Store.get(this)
        val ch = NotificationChannel(CHANNEL, "Refresh watcher", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = buildNotification("Ready")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        if (job == null) job = scope.launch { loop() }
        return START_STICKY
    }

    private suspend fun loop() {
        val tracker = ForegroundTracker(this)
        val power = getSystemService(PowerManager::class.java)
        val display = getSystemService(DisplayManager::class.java)
        var applied = false
        var appliedHz = 0
        var lastText = ""
        while (true) {
            if (store.appRates.value.isEmpty()) {
                RefreshController.restore(this)
                stopSelf()
                return
            }
            val interactive = power.isInteractive
            if (interactive) {
                val pkg = tracker.poll()
                val hz = if (pkg != null) store.appRates.value[pkg] ?: 0 else 0
                if (hz > 0 && (!applied || appliedHz != hz)) {
                    if (RefreshController.apply(this, hz)) {
                        applied = true
                        appliedHz = hz
                    }
                } else if (hz == 0 && applied) {
                    RefreshController.restore(this)
                    applied = false
                }
                val cur = display.getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate?.roundToInt() ?: 0
                val minNow = Settings.System.getString(contentResolver, "min_refresh_rate")
                val text = if (applied && pkg != null) {
                    "${labelOf(pkg)}: target $appliedHz Hz, display now $cur Hz (min_refresh_rate=$minNow)"
                } else {
                    "Watching ${store.appRates.value.size} apps, display now $cur Hz"
                }
                if (text != lastText) {
                    lastText = text
                    getSystemService(NotificationManager::class.java)
                        .notify(NOTIF_ID, buildNotification(text))
                }
            }
            delay(if (interactive) 300L else 2500L)
        }
    }

    private fun labelOf(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: PackageManager.NameNotFoundException) {
        pkg
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_hz)
            .setContentTitle("RefreshX")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        RefreshController.restore(this)
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "watch"
        private const val NOTIF_ID = 1
    }
}
