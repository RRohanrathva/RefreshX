package com.refreshx.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class RefreshService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private lateinit var store: Store

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        store = Store.get(this)
        val ch = NotificationChannel(CHANNEL, "Refresh watcher", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            store.setServiceOn(false)
            stopSelf()
            return START_NOT_STICKY
        }
        val n = buildNotification("Starting…")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        store.setServiceOn(true)
        if (job == null) job = scope.launch { loop() }
        return START_STICKY
    }

    private suspend fun loop() {
        val tracker = ForegroundTracker(this)
        val power = getSystemService(PowerManager::class.java)
        var applied = false
        var appliedHz = 0
        var lastText = ""
        while (true) {
            val interactive = power.isInteractive
            if (interactive) {
                val pkg = tracker.poll()
                val hz = store.targetHz.value
                val want = pkg != null && pkg in store.enabledApps.value
                if (want && (!applied || appliedHz != hz)) {
                    if (RefreshController.apply(this, hz)) {
                        applied = true
                        appliedHz = hz
                    }
                } else if (!want && applied) {
                    RefreshController.restore(this)
                    applied = false
                }
                val text = if (applied && pkg != null) {
                    "$appliedHz Hz forced in ${labelOf(pkg)}"
                } else {
                    "Watching ${store.enabledApps.value.size} apps"
                }
                if (text != lastText) {
                    lastText = text
                    getSystemService(NotificationManager::class.java)
                        .notify(NOTIF_ID, buildNotification(text))
                }
            }
            delay(if (interactive) 400L else 2500L)
        }
    }

    private fun labelOf(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: PackageManager.NameNotFoundException) {
        pkg
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, RefreshService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_hz)
            .setContentTitle("RefreshX")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        RefreshController.restore(this)
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "watch"
        private const val NOTIF_ID = 1
        const val ACTION_STOP = "com.refreshx.app.STOP"
    }
}
