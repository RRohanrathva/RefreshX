package com.refreshx.app

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.provider.Settings
import android.view.Display
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Refresh-rate force karva na 3 rasta ek sathe vaapre chhe:
 *  1. Settings keys: min_refresh_rate / peak_refresh_rate (standard Android)
 *     + Xiaomi/HyperOS: miui_refresh_rate / user_refresh_rate
 *  2. Shizuku shell: `cmd display set-user-preferred-display-mode W H Hz`
 *  3. Jo "Modify system settings" na hoy to Shizuku shell thi `settings put`
 * Original values pehla save thay chhe ane app mathi bahar nikdta restore thay chhe.
 */
object RefreshController {
    private val FLOAT_KEYS = listOf("min_refresh_rate", "peak_refresh_rate")
    private val XIAOMI_INT_KEYS = listOf("miui_refresh_rate", "user_refresh_rate")

    private fun isXiaomi(): Boolean {
        val s = (Build.MANUFACTURER + " " + Build.BRAND).lowercase()
        return s.contains("xiaomi") || s.contains("redmi") || s.contains("poco")
    }

    private fun intKeys(): List<String> = if (isXiaomi()) XIAOMI_INT_KEYS else emptyList()

    private fun allKeys(): List<String> = FLOAT_KEYS + intKeys()

    private fun shellReady() = ShizukuHelper.state.value == ShizukuState.READY

    /** `cmd display set-user-preferred-display-mode` command for the closest supported mode. */
    private fun preferredModeCmd(ctx: Context, hz: Int): String? {
        val d = ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY) ?: return null
        val cur = d.mode
        val m = d.supportedModes
            .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
            .minByOrNull { abs(it.refreshRate - hz) } ?: return null
        if (abs(m.refreshRate - hz) > 1.5f) return null
        return "cmd display set-user-preferred-display-mode ${m.physicalWidth} ${m.physicalHeight} ${m.refreshRate}"
    }

    fun apply(ctx: Context, hz: Int): Boolean {
        val store = Store.get(ctx)
        val cr = ctx.contentResolver
        if (!store.forced) {
            try {
                allKeys().forEach { store.saveOriginal(it, Settings.System.getString(cr, it)) }
                store.forced = true
            } catch (e: Exception) {
                // ignore
            }
        }
        var ok = false
        if (Settings.System.canWrite(ctx)) {
            try {
                FLOAT_KEYS.forEach { Settings.System.putString(cr, it, "${hz}.0") }
                intKeys().forEach { Settings.System.putString(cr, it, hz.toString()) }
                ok = true
            } catch (e: Exception) {
                // fall through to shell
            }
        }
        if (shellReady()) {
            val cmds = ArrayList<String>()
            if (!ok) {
                cmds += FLOAT_KEYS.map { "settings put system $it ${hz}.0" }
                cmds += intKeys().map { "settings put system $it $hz" }
            }
            preferredModeCmd(ctx, hz)?.let {
                cmds += it
                store.prefMode = true
            }
            if (cmds.isNotEmpty() && ShizukuHelper.exec(cmds.joinToString("; ")) != null) ok = true
        }
        return ok
    }

    fun restore(ctx: Context) {
        val store = Store.get(ctx)
        if (!store.forced && !store.prefMode) return
        val cr = ctx.contentResolver
        var settingsDone = !store.forced
        if (store.forced && Settings.System.canWrite(ctx)) {
            try {
                // null value => setting removed again (back to system default)
                allKeys().forEach { Settings.System.putString(cr, it, store.original(it)) }
                store.forced = false
                settingsDone = true
            } catch (e: Exception) {
                // fall through to shell
            }
        }
        if (shellReady()) {
            val cmds = ArrayList<String>()
            if (!settingsDone) {
                cmds += allKeys().map {
                    val o = store.original(it)
                    if (o == null) "settings delete system $it" else "settings put system $it $o"
                }
            }
            if (store.prefMode) cmds += "cmd display clear-user-preferred-display-mode"
            if (cmds.isNotEmpty() && ShizukuHelper.exec(cmds.joinToString("; ")) != null) {
                store.forced = false
                store.prefMode = false
            }
        }
    }

    /** Text for the in-app Diagnostics card. */
    fun diagnostics(ctx: Context): String {
        val cr = ctx.contentResolver
        val d = ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val sb = StringBuilder()
        sb.appendLine("Display now: ${d?.refreshRate?.let { "%.1f".format(it) } ?: "?"} Hz")
        sb.appendLine(
            "Modes: " + (d?.supportedModes?.joinToString { "${it.modeId}:${it.refreshRate.roundToInt()}Hz" } ?: "?")
        )
        (FLOAT_KEYS + XIAOMI_INT_KEYS).forEach { sb.appendLine("$it = ${Settings.System.getString(cr, it)}") }
        sb.appendLine("Write settings: ${Settings.System.canWrite(ctx)}")
        sb.appendLine("Shizuku: ${ShizukuHelper.state.value}")
        sb.appendLine("Service: ${RefreshService.status}")
        return sb.toString().trim()
    }
}
