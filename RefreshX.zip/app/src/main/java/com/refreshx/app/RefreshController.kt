package com.refreshx.app

import android.content.Context
import android.provider.Settings

/**
 * Writes the system refresh-rate settings (needs the user-grantable "Modify system settings"
 * permission). Original values are saved first and restored when the app is left.
 */
object RefreshController {
    private val FLOAT_KEYS = listOf("min_refresh_rate", "peak_refresh_rate")
    private val EXTRA_INT_KEYS = listOf("miui_refresh_rate") // only touched if it already exists

    fun apply(ctx: Context, hz: Int): Boolean {
        if (!Settings.System.canWrite(ctx)) return false
        val cr = ctx.contentResolver
        val store = Store.get(ctx)
        return try {
            if (!store.forced) {
                (FLOAT_KEYS + EXTRA_INT_KEYS).forEach {
                    store.saveOriginal(it, Settings.System.getString(cr, it))
                }
                store.forced = true
            }
            FLOAT_KEYS.forEach { Settings.System.putString(cr, it, "${hz}.0") }
            EXTRA_INT_KEYS.forEach {
                if (store.original(it) != null) Settings.System.putString(cr, it, hz.toString())
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun restore(ctx: Context) {
        val store = Store.get(ctx)
        if (!store.forced) return
        if (!Settings.System.canWrite(ctx)) return
        val cr = ctx.contentResolver
        try {
            (FLOAT_KEYS + EXTRA_INT_KEYS).forEach {
                // null value => setting removed again (back to system default)
                Settings.System.putString(cr, it, store.original(it))
            }
            store.forced = false
        } catch (e: Exception) {
            // ignore
        }
    }
}
