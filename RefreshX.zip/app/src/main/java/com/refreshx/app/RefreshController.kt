package com.refreshx.app

import android.content.Context
import android.os.Build
import android.provider.Settings

/**
 * Refresh-rate settings write kare chhe. Original values pehla save thay chhe ane
 * app mathi bahar nikdta restore thay chhe.
 *
 * - Standard Android: min_refresh_rate / peak_refresh_rate (float)
 * - Xiaomi / Redmi / POCO (HyperOS): miui_refresh_rate / user_refresh_rate (int) pan
 * - Jo "Modify system settings" na hoy to Shizuku shell (`settings put`) thi
 */
object RefreshController {
    private val FLOAT_KEYS = listOf("min_refresh_rate", "peak_refresh_rate")
    private val XIAOMI_INT_KEYS = listOf("miui_refresh_rate", "user_refresh_rate")

    private fun isXiaomi(): Boolean {
        val s = (Build.MANUFACTURER + " " + Build.BRAND).lowercase()
        return s.contains("xiaomi") || s.contains("redmi") || s.contains("poco")
    }

    private fun intKeys(): List<String> = if (isXiaomi()) XIAOMI_INT_KEYS else emptyList()

    private fun allKeys(): List<String> = FLOAT_KEYS + intKeys()

    private fun shellReady() = ShizukuHelper.state.value == ShizukuState.READY

    fun apply(ctx: Context, hz: Int): Boolean {
        val store = Store.get(ctx)
        val cr = ctx.contentResolver
        if (!store.forced) {
            try {
                allKeys().forEach { store.saveOriginal(it, Settings.System.getString(cr, it)) }
                store.forced = true
            } catch (e: Exception) {
                // ignore
            }
        }
        if (Settings.System.canWrite(ctx)) {
            try {
                FLOAT_KEYS.forEach { Settings.System.putString(cr, it, "${hz}.0") }
                intKeys().forEach { Settings.System.putString(cr, it, hz.toString()) }
                return true
            } catch (e: Exception) {
                // fall through to shell
            }
        }
        if (shellReady()) {
            val cmd = (FLOAT_KEYS.map { "settings put system $it ${hz}.0" } +
                intKeys().map { "settings put system $it $hz" }).joinToString("; ")
            return ShizukuHelper.exec(cmd) != null
        }
        return false
    }

    fun restore(ctx: Context) {
        val store = Store.get(ctx)
        if (!store.forced) return
        val cr = ctx.contentResolver
        if (Settings.System.canWrite(ctx)) {
            try {
                // null value => setting removed again (back to system default)
                allKeys().forEach { Settings.System.putString(cr, it, store.original(it)) }
                store.forced = false
                return
            } catch (e: Exception) {
                // fall through to shell
            }
        }
        if (shellReady()) {
            val cmd = allKeys().joinToString("; ") {
                val o = store.original(it)
                if (o == null) "settings delete system $it" else "settings put system $it $o"
            }
            if (ShizukuHelper.exec(cmd) != null) store.forced = false
        }
    }
}
