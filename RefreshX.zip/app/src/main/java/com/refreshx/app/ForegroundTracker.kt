package com.refreshx.app

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context

/** Finds out which app is currently in the foreground using usage-access events. */
class ForegroundTracker(ctx: Context) {
    private val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    private var lastTime = System.currentTimeMillis() - 60_000
    private var current: String? = null

    fun poll(): String? {
        return try {
            val now = System.currentTimeMillis()
            val events = usm.queryEvents(lastTime, now)
            val e = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                    current = e.packageName
                }
            }
            lastTime = now - 2_000
            current
        } catch (t: Throwable) {
            current
        }
    }
}
