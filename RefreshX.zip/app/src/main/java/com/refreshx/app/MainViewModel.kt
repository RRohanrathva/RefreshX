package com.refreshx.app

import android.app.Application
import android.content.Intent
import android.hardware.display.DisplayManager
import android.view.Display
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

data class AppItem(val label: String, val pkg: String)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store.get(app)

    val appRates = store.appRates
    val shizuku = ShizukuHelper.state
    val setupTick = ShizukuHelper.setupTick
    val apps = MutableStateFlow<List<AppItem>>(emptyList())
    val loading = MutableStateFlow(true)

    /** Display na supported refresh rates (60, 90, 120...). */
    val rates: List<Int> = run {
        val dm = app.getSystemService(DisplayManager::class.java)
        val modes = dm.getDisplay(Display.DEFAULT_DISPLAY)?.supportedModes ?: emptyArray()
        val r = modes.map { it.refreshRate.roundToInt() }.filter { it >= 60 }.distinct().sorted()
        if (r.isEmpty()) listOf(60, 90, 120) else r
    }

    init {
        ShizukuHelper.init(app)
        sync()
        viewModelScope.launch(Dispatchers.IO) {
            apps.value = loadApps()
            loading.value = false
        }
    }

    private fun loadApps(): List<AppItem> {
        val ctx = getApplication<Application>()
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != ctx.packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    fun setRate(pkg: String, hz: Int) {
        store.setRate(pkg, hz)
        sync()
    }

    /** Koi app ma rate set hoy ane permission hoy to service automatic chalu, nahi to band. */
    fun sync() {
        val ctx = getApplication<Application>()
        val i = Intent(ctx, RefreshService::class.java)
        val has = store.appRates.value.isNotEmpty()
        if (has && Perms.state(ctx).core) {
            runCatching { ContextCompat.startForegroundService(ctx, i) }
        } else {
            ctx.stopService(i)
            RefreshController.restore(ctx)
        }
    }

    fun requestShizuku() = ShizukuHelper.requestPermission()

    fun retrySetup() = ShizukuHelper.setup(getApplication())
}
