package com.refreshx.app

import android.app.Application
import android.content.Intent
import android.hardware.display.DisplayManager
import android.view.Display
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

data class AppItem(val label: String, val pkg: String)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store.get(app)

    val enabled = store.enabledApps
    val targetHz = store.targetHz
    val serviceOn = store.serviceOn
    val apps = MutableStateFlow<List<AppItem>>(emptyList())
    val loading = MutableStateFlow(true)

    val rates: List<Int> = run {
        val dm = app.getSystemService(DisplayManager::class.java)
        val modes = dm.getDisplay(Display.DEFAULT_DISPLAY)?.supportedModes ?: emptyArray()
        val r = modes.map { it.refreshRate.roundToInt() }.filter { it >= 60 }.distinct().sorted()
        if (r.isEmpty()) listOf(60, 90, 120) else r
    }

    init {
        if (store.targetHz.value !in rates) store.setHz(rates.max())
        // Safety: service band hoy to koi purana forced values reset karo
        if (!store.serviceOn.value) RefreshController.restore(app)
        viewModelScope.launch(Dispatchers.IO) {
            apps.value = loadApps()
            loading.value = false
        }
    }

    private fun loadApps(): List<AppItem> {
        val ctx = getApplication<Application>()
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != ctx.packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    fun toggleApp(pkg: String, on: Boolean) = store.setApp(pkg, on)

    fun setHz(hz: Int) = store.setHz(hz)

    fun setService(on: Boolean) {
        val ctx = getApplication<Application>()
        val i = Intent(ctx, RefreshService::class.java)
        if (on) {
            store.setServiceOn(true)
            ContextCompat.startForegroundService(ctx, i)
        } else {
            store.setServiceOn(false)
            ctx.stopService(i)
            RefreshController.restore(ctx)
        }
    }

    fun resetRefresh() {
        RefreshController.restore(getApplication())
    }
}
