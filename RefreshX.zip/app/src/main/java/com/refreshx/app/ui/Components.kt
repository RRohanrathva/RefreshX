@file:OptIn(ExperimentalMaterial3Api::class)

package com.refreshx.app.ui

import android.content.pm.PackageManager
import android.util.LruCache
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.refreshx.app.AppItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** Staggered fade + slide + scale entrance (plays once, survives scrolling/rotation). */
@Composable
fun Entrance(index: Int, content: @Composable () -> Unit) {
    var show by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        if (!show) {
            delay(index * 80L)
            show = true
        }
    }
    AnimatedVisibility(
        visible = show,
        enter = fadeIn(tween(450)) +
            slideInVertically(
                animationSpec = spring(dampingRatio = 0.75f, stiffness = Spring.StiffnessLow),
                initialOffsetY = { it / 5 }
            ) +
            scaleIn(initialScale = 0.93f, animationSpec = tween(450)),
    ) {
        content()
    }
}

// ---------- App icons ----------

private object IconCache {
    private val cache = LruCache<String, ImageBitmap>(250)
    fun peek(pkg: String): ImageBitmap? = cache.get(pkg)
    fun load(pm: PackageManager, pkg: String): ImageBitmap? {
        cache.get(pkg)?.let { return it }
        return try {
            val bmp = pm.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
            cache.put(pkg, bmp)
            bmp
        } catch (e: Exception) {
            null
        }
    }
}

@Composable
fun AppIcon(pkg: String, modifier: Modifier = Modifier) {
    val pm = LocalContext.current.packageManager
    val icon by produceState<ImageBitmap?>(IconCache.peek(pkg), pkg) {
        if (value == null) value = withContext(Dispatchers.Default) { IconCache.load(pm, pkg) }
    }
    val shape = RoundedCornerShape(14.dp)
    AnimatedContent(
        targetState = icon,
        transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(250)) },
        modifier = modifier.size(46.dp).clip(shape),
        label = "icon",
    ) { bmp ->
        if (bmp != null) {
            Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(46.dp))
        } else {
            Box(Modifier.size(46.dp).background(MaterialTheme.colorScheme.surfaceVariant))
        }
    }
}

// ---------- Header ----------

@Composable
fun Header() {
    Column(Modifier.padding(start = 8.dp, top = 8.dp, bottom = 20.dp)) {
        Text(
            "RefreshX",
            style = MaterialTheme.typography.displayMedium,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            "High refresh rate, app by app",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

// ---------- Hero ----------

@Composable
fun HeroCard(
    on: Boolean,
    hz: Int,
    ready: Boolean,
    enabledCount: Int,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val corner by animateDpAsState(
        if (on) 56.dp else 32.dp,
        spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessLow),
        label = "corner",
    )
    val container by animateColorAsState(
        if (on) cs.primaryContainer else cs.surfaceContainerHigh, tween(600), label = "container"
    )
    val orb by animateColorAsState(
        if (on) cs.primary else cs.outlineVariant, tween(600), label = "orb"
    )
    val orbText by animateColorAsState(
        if (on) cs.onPrimary else cs.onSurfaceVariant, tween(600), label = "orbText"
    )
    val infinite = rememberInfiniteTransition(label = "pulse")
    val pulse by infinite.animateFloat(
        initialValue = 1f,
        targetValue = 1.14f,
        animationSpec = infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulseScale",
    )
    val ringScale = if (on) pulse else 1f

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(corner),
        colors = CardDefaults.cardColors(containerColor = container),
    ) {
        Column(
            Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.size(176.dp), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.size(176.dp)
                        .graphicsLayer { scaleX = ringScale; scaleY = ringScale }
                        .background(orb.copy(alpha = 0.16f), CircleShape)
                )
                Box(
                    Modifier.size(140.dp).background(orb, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        AnimatedContent(
                            targetState = hz,
                            transitionSpec = {
                                (slideInVertically { it } + fadeIn()) togetherWith
                                    (slideOutVertically { -it } + fadeOut())
                            },
                            label = "hz",
                        ) { value ->
                            Text(
                                "$value",
                                fontSize = 52.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = orbText,
                            )
                        }
                        Text("Hz", style = MaterialTheme.typography.titleMedium, color = orbText)
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            AnimatedContent(
                targetState = when {
                    on -> "Active · watching $enabledCount apps"
                    ready -> "Paused"
                    else -> "Finish setup to begin"
                },
                transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(300)) },
                label = "status",
            ) { text ->
                Text(
                    text,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = if (on) cs.onPrimaryContainer else cs.onSurface,
                )
            }
            Spacer(Modifier.height(18.dp))
            Button(
                onClick = onToggle,
                enabled = ready || on,
                modifier = Modifier.fillMaxWidth().height(58.dp),
                shape = CircleShape,
                colors = if (on) ButtonDefaults.buttonColors(
                    containerColor = cs.errorContainer, contentColor = cs.onErrorContainer
                ) else ButtonDefaults.buttonColors(),
            ) {
                AnimatedContent(
                    targetState = on,
                    transitionSpec = {
                        (slideInVertically { it / 2 } + fadeIn()) togetherWith
                            (slideOutVertically { -it / 2 } + fadeOut())
                    },
                    label = "btn",
                ) { isOn ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (isOn) Icons.Rounded.Stop else Icons.Rounded.PlayArrow, null)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (isOn) "Stop" else "Start",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
        }
    }
}

// ---------- Setup ----------

@Composable
fun SetupCard(
    write: Boolean,
    usage: Boolean,
    notif: Boolean,
    onWrite: () -> Unit,
    onUsage: () -> Unit,
    onNotif: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier.fillMaxWidth().animateContentSize(),
        shape = RoundedCornerShape(32.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                "Quick setup",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onTertiaryContainer,
            )
            PermRow(Icons.Rounded.Settings, "Modify system settings", "Refresh rate change karva mate", write, onWrite)
            PermRow(Icons.Rounded.Visibility, "Usage access", "Kayo app khulelo chhe te jaanva mate", usage, onUsage)
            PermRow(Icons.Rounded.Notifications, "Notifications", "Service chaalu chhe te batavva mate", notif, onNotif)
        }
    }
}

@Composable
private fun PermRow(icon: ImageVector, title: String, desc: String, granted: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(44.dp).background(cs.surface.copy(alpha = 0.6f), CircleShape),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, null, tint = cs.onTertiaryContainer) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = cs.onTertiaryContainer)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = cs.onTertiaryContainer.copy(alpha = 0.8f))
        }
        Spacer(Modifier.width(8.dp))
        AnimatedContent(
            targetState = granted,
            transitionSpec = { (scaleIn(spring(0.5f, Spring.StiffnessMedium)) + fadeIn()) togetherWith fadeOut() },
            label = "perm",
        ) { ok ->
            if (ok) {
                Box(
                    Modifier.size(36.dp).background(cs.primary, CircleShape),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Check, null, tint = cs.onPrimary) }
            } else {
                FilledTonalButton(onClick = onClick) { Text("Allow") }
            }
        }
    }
}

// ---------- Hz selector ----------

@Composable
fun HzCard(rates: List<Int>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(32.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
    ) {
        Column(Modifier.padding(20.dp)) {
            Text("Target refresh rate", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "Selected apps ma aa Hz force thase",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rates.forEach { r ->
                    FilterChip(
                        selected = r == selected,
                        onClick = { onSelect(r) },
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = CircleShape,
                        label = {
                            Text(
                                "$r",
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Center,
                                fontWeight = FontWeight.Bold,
                            )
                        },
                    )
                }
            }
        }
    }
}

// ---------- Tips ----------

@Composable
fun TipsCard(onAppSettings: () -> Unit, onReset: () -> Unit, modifier: Modifier = Modifier) {
    var open by rememberSaveable { mutableStateOf(false) }
    Card(
        onClick = { open = !open },
        modifier = modifier.fillMaxWidth().animateContentSize(spring(0.8f, Spring.StiffnessMediumLow)),
        shape = RoundedCornerShape(32.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Info, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(12.dp))
                Text(
                    "Keep it running smoothly",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
            }
            AnimatedVisibility(open) {
                Column(Modifier.padding(top = 12.dp)) {
                    Text(
                        "• Battery: No restrictions rakho\n" +
                            "• Autostart / Background activity ON karo (HyperOS, ColorOS vagere)\n" +
                            "• Recent apps ma RefreshX ne lock karo\n" +
                            "• Rate na badle to display settings ma High refresh rate ON rakho",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(onClick = onAppSettings) {
                            Icon(Icons.Rounded.Settings, null)
                            Spacer(Modifier.width(6.dp))
                            Text("App settings")
                        }
                        OutlinedButton(onClick = onReset) {
                            Icon(Icons.Rounded.RestartAlt, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Reset Hz")
                        }
                    }
                }
            }
        }
    }
}

// ---------- App row ----------

@Composable
fun AppRow(app: AppItem, checked: Boolean, onChange: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.96f else 1f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "press"
    )
    val bg by animateColorAsState(
        if (checked) cs.secondaryContainer else cs.surfaceContainer, tween(350), label = "bg"
    )
    val corner by animateDpAsState(
        if (checked) 32.dp else 20.dp,
        spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow),
        label = "corner",
    )
    Surface(
        onClick = { onChange(!checked) },
        interactionSource = source,
        shape = RoundedCornerShape(corner),
        color = bg,
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale },
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AppIcon(app.pkg)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    app.label,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    app.pkg,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.width(8.dp))
            Switch(
                checked = checked,
                onCheckedChange = null,
                thumbContent = if (checked) {
                    { Icon(Icons.Rounded.Check, null, Modifier.size(SwitchDefaults.IconSize)) }
                } else null,
            )
        }
    }
}
