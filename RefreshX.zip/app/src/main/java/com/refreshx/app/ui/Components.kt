package com.refreshx.app.ui

import android.content.pm.PackageManager
import android.util.LruCache
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.refreshx.app.AppItem
import com.refreshx.app.ShizukuState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** Staggered fade + slide + scale entrance (plays once, survives scrolling/rotation). */
@Composable
fun Entrance(index: Int, content: @Composable () -> Unit) {
    var show by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        if (!show) {
            delay(index * 80L)
            show = true
        }
    }
    AnimatedVisibility(
        visible = show,
        enter = fadeIn(tween(450)) +
            slideInVertically(
                animationSpec = spring(dampingRatio = 0.75f, stiffness = Spring.StiffnessLow),
                initialOffsetY = { it / 5 }
            ) +
            scaleIn(initialScale = 0.93f, animationSpec = tween(450)),
    ) {
        content()
    }
}

// ---------- App icons ----------

private object IconCache {
    private val cache = LruCache<String, ImageBitmap>(250)
    fun peek(pkg: String): ImageBitmap? = cache.get(pkg)
    fun load(pm: PackageManager, pkg: String): ImageBitmap? {
        cache.get(pkg)?.let { return it }
        return try {
            val bmp = pm.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
            cache.put(pkg, bmp)
            bmp
        } catch (e: Exception) {
            null
        }
    }
}

@Composable
fun AppIcon(pkg: String, modifier: Modifier = Modifier) {
    val pm = LocalContext.current.packageManager
    val icon by produceState<ImageBitmap?>(IconCache.peek(pkg), pkg) {
        if (value == null) value = withContext(Dispatchers.Default) { IconCache.load(pm, pkg) }
    }
    AnimatedContent(
        targetState = icon,
        transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(250)) },
        modifier = modifier.size(46.dp).clip(RoundedCornerShape(14.dp)),
        label = "icon",
    ) { bmp ->
        if (bmp != null) {
            Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(46.dp))
        } else {
            Box(Modifier.size(46.dp).background(MaterialTheme.colorScheme.surfaceVariant))
        }
    }
}

// ---------- Header ----------

@Composable
fun Header() {
    Column(Modifier.padding(start = 8.dp, top = 8.dp, bottom = 20.dp)) {
        Text(
            "RefreshX",
            style = MaterialTheme.typography.displayMedium,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            "App select karo, Hz select karo. Bas.",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

// ---------- Shizuku status ----------

@Composable
fun ShizukuCard(
    state: ShizukuState,
    onOpen: () -> Unit,
    onAllow: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(32.dp),
        colors = CardDefaults.cardColors(containerColor = cs.tertiaryContainer),
    ) {
        Column(Modifier.padding(20.dp)) {
            Text(
                "Shizuku setup",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = cs.onTertiaryContainer,
            )
            Spacer(Modifier.height(6.dp))
            AnimatedContent(
                targetState = state,
                transitionSpec = {
                    (slideInVertically { it / 3 } + fadeIn()) togetherWith
                        (slideOutVertically { -it / 3 } + fadeOut())
                },
                label = "shizuku",
            ) { s ->
                Column {
                    Text(
                        when (s) {
                            ShizukuState.NOT_RUNNING ->
                                "Shizuku app chalu karo (Wireless debugging thi Start), pachi aahi pacha aavo."
                            ShizukuState.NEEDS_PERMISSION ->
                                "RefreshX ne Shizuku ni permission aapo. Baaki badhi permissions automatic set thase."
                            ShizukuState.READY ->
                                "Permissions set thai rahi chhe..."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onTertiaryContainer,
                    )
                    Spacer(Modifier.height(14.dp))
                    when (s) {
                        ShizukuState.NOT_RUNNING -> Button(onClick = onOpen) { Text("Open Shizuku") }
                        ShizukuState.NEEDS_PERMISSION -> Button(onClick = onAllow) { Text("Allow") }
                        ShizukuState.READY -> FilledTonalButton(onClick = onRetry) {
                            Icon(Icons.Rounded.Refresh, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Retry")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReadyPill(modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = modifier,
        shape = CircleShape,
        color = cs.primaryContainer,
    ) {
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.Bolt, null, tint = cs.onPrimaryContainer)
            Spacer(Modifier.width(8.dp))
            Text(
                "Ready. Selected app khulta j Hz automatic set thase",
                style = MaterialTheme.typography.labelLarge,
                color = cs.onPrimaryContainer,
            )
        }
    }
}

// ---------- App row ----------

@Composable
fun AppRow(
    app: AppItem,
    rate: Int,
    rates: List<Int>,
    onRate: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val active = rate > 0
    val bg by animateColorAsState(
        if (active) cs.secondaryContainer else cs.surfaceContainer, tween(350), label = "bg"
    )
    val corner by animateDpAsState(
        if (active) 32.dp else 22.dp,
        spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow),
        label = "corner",
    )
    Surface(
        shape = RoundedCornerShape(corner),
        color = bg,
        modifier = modifier.fillMaxWidth().padding(vertical = 4.dp),
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(app.pkg)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        app.label,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        app.pkg,
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                AnimatedContent(
                    targetState = rate,
                    transitionSpec = {
                        (slideInVertically { it } + fadeIn()) togetherWith
                            (slideOutVertically { -it } + fadeOut())
                    },
                    label = "badge",
                ) { r ->
                    Text(
                        if (r > 0) "$r Hz" else "",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = cs.primary,
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (listOf(0) + rates).forEach { option ->
                    FilterChip(
                        selected = rate == option,
                        onClick = { onRate(option) },
                        modifier = Modifier.weight(1f),
                        shape = CircleShape,
                        label = {
                            Text(
                                if (option == 0) "Off" else "$option",
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Center,
                                fontWeight = FontWeight.Bold,
                            )
                        },
                    )
                }
            }
        }
    }
}
