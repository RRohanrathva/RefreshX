package com.refreshx.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val store = Store.get(context)
        // Boot par purano forced state clear karo
        store.forced = false
        if (store.serviceOn.value && Settings.System.canWrite(context)) {
            runCatching {
                ContextCompat.startForegroundService(context, Intent(context, RefreshService::class.java))
            }
        }
    }
}
