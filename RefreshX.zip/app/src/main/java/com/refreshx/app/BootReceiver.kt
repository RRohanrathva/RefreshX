package com.refreshx.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val store = Store.get(context)
        store.forced = false
        if (store.appRates.value.isNotEmpty() && Settings.System.canWrite(context)) {
            runCatching {
                ContextCompat.startForegroundService(context, Intent(context, RefreshService::class.java))
            }
        }
    }
}
