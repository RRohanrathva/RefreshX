package com.refreshx.app

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow

/** Per-app refresh rate map (pkg -> Hz). 0 / missing = Off. */
class Store private constructor(ctx: Context) {
    private val sp = ctx.getSharedPreferences("refreshx", Context.MODE_PRIVATE)

    val appRates = MutableStateFlow(load())

    private fun load(): Map<String, Int> {
        val out = HashMap<String, Int>()
        for (s in sp.getStringSet("rates", emptySet()) ?: emptySet()) {
            val i = s.lastIndexOf('|')
            if (i < 0) continue
            val hz = s.substring(i + 1).toIntOrNull() ?: continue
            if (hz > 0) out[s.substring(0, i)] = hz
        }
        return out
    }

    fun setRate(pkg: String, hz: Int) {
        val m = appRates.value.toMutableMap()
        if (hz <= 0) m.remove(pkg) else m[pkg] = hz
        appRates.value = m
        sp.edit().putStringSet("rates", m.map { "${it.key}|${it.value}" }.toSet()).apply()
    }

    /** True while we have overridden the system refresh-rate settings. */
    var forced: Boolean
        get() = sp.getBoolean("forced", false)
        set(v) {
            sp.edit().putBoolean("forced", v).apply()
        }

    /** True while a user-preferred display mode set by us is active. */
    var prefMode: Boolean
        get() = sp.getBoolean("prefMode", false)
        set(v) {
            sp.edit().putBoolean("prefMode", v).apply()
        }

    fun saveOriginal(key: String, value: String?) {
        sp.edit().putString("orig_$key", value ?: NONE).apply()
    }

    fun original(key: String): String? {
        val v = sp.getString("orig_$key", null)
        return if (v == null || v == NONE) null else v
    }

    companion object {
        private const val NONE = "\u0000none"

        @Volatile
        private var inst: Store? = null

        fun get(ctx: Context): Store =
            inst ?: synchronized(this) {
                inst ?: Store(ctx.applicationContext).also { inst = it }
            }
    }
}
