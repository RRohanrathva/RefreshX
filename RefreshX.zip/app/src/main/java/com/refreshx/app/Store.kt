package com.refreshx.app

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow

/** Simple SharedPreferences store with in-memory flows for the UI. */
class Store private constructor(ctx: Context) {
    private val sp = ctx.getSharedPreferences("refreshx", Context.MODE_PRIVATE)

    val enabledApps = MutableStateFlow(sp.getStringSet("apps", emptySet())!!.toSet())
    val targetHz = MutableStateFlow(sp.getInt("hz", 120))
    val serviceOn = MutableStateFlow(sp.getBoolean("on", false))

    fun setApp(pkg: String, on: Boolean) {
        val next = enabledApps.value.toMutableSet().apply { if (on) add(pkg) else remove(pkg) }
        enabledApps.value = next
        sp.edit().putStringSet("apps", next).apply()
    }

    fun setHz(hz: Int) {
        targetHz.value = hz
        sp.edit().putInt("hz", hz).apply()
    }

    fun setServiceOn(on: Boolean) {
        serviceOn.value = on
        sp.edit().putBoolean("on", on).apply()
    }

    /** True while we have overridden the system refresh-rate settings. */
    var forced: Boolean
        get() = sp.getBoolean("forced", false)
        set(v) {
            sp.edit().putBoolean("forced", v).apply()
        }

    fun saveOriginal(key: String, value: String?) {
        sp.edit().putString("orig_$key", value ?: NONE).apply()
    }

    fun original(key: String): String? {
        val v = sp.getString("orig_$key", null)
        return if (v == null || v == NONE) null else v
    }

    companion object {
        private const val NONE = "\u0000none"

        @Volatile
        private var inst: Store? = null

        fun get(ctx: Context): Store =
            inst ?: synchronized(this) {
                inst ?: Store(ctx.applicationContext).also { inst = it }
            }
    }
}
